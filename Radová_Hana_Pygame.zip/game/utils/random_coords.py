
import random

#funkce řeší náhodné pozice na kterých je možno se objevit
def random_coords(obj):
    w, h = obj.screen.get_size()
    obj.x = random.randint(0, w - obj.width)
    obj.y = random.randint(0, h - obj.height)
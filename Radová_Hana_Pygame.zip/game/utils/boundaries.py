def boundaries(obj):
    #funce řeší okraje obrazovky a je použita např. u jednorožce
    w, h = obj.screen.get_size()
    obj.x = max(
        0, min(obj.x, w - obj.width)
    )
    obj.y = max(
        0, min(obj.y, h - obj.height)
    )
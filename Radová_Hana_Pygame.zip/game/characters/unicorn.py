import pygame
from utils.boundaries import boundaries

class Unicorn:
    def __init__(self,x,y,width,height,speed):
        self.x = x
        self.y = y
        self.width = 180
        self.height = 150
        self.image_index = 0  # Index aktuálního obrázku jednorožce
        self.images = [pygame.transform.scale(pygame.image.load(r"pictures\unicorn{}.png".format(i)), (self.width, self.height)) for i in range(1, 6)]
        self.speed = speed
        self.collision_rect = pygame.Rect(self.x, self.y, self.width, self.height)
        self.screen = pygame.display.get_surface()
        self.hp = 3
        self.last_update_time = pygame.time.get_ticks()
        
    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update_time > 1000 * 0.1 : #změna rychlosti je možná zde
            self.last_update_time = now
            self.image_index = (self.image_index + 1) % len(self.images)
        
    def update(self):
        keys = pygame.key.get_pressed()
        self.animate()
        self.move(keys)
        self.draw()
        
    #následující kód řeší pohyb jednorožce při stisku kláves WASD
    def move(self, keys):
        if keys[pygame.K_a]:
            self.x -= self.speed

        if keys[pygame.K_d]:
            self.x += self.speed

        if keys[pygame.K_s]:
            self.y += self.speed

        if keys[pygame.K_w]:
            self.y -= self.speed

        boundaries(self)
        
    def draw(self):
        self.screen.blit(self.images[self.image_index], (self.x, self.y))
        self.collision_rect = pygame.Rect(self.x, self.y, self.width, self.height)

   
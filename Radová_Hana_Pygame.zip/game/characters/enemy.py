import pygame
import random
from utils.random_coords import random_coords
#Tato složka obsahuje blesky, kterým je třeba se vyhnout

class FloatingEnemy():
    #typ blesku, který zůstává na místě a otáčí se kolem své osy
    def __init__(self):
        self.width = 50
        self.height = 50
        self.last_update_time = 0
        self.image_index = 0
        self.screen = pygame.display.get_surface()
        random_coords(self)
        self.collision_rect = pygame.Rect(self.x, self.y, self.width, self.height)
        blesk_red_img = pygame.image.load("pictures/blesk2.png").convert_alpha() #červený obrázek
        blesk_blue_img = pygame.image.load("pictures/blesk3.png").convert_alpha() #modrý obrázek
        frames_blesk = []
        
        for col in range(6):
            frame_rect = (col * 32, 0, 32, 35)
            frame = blesk_red_img.subsurface(frame_rect)
            frame = pygame.transform.scale(frame, (self.width + 7, self.height + 7))
            frames_blesk.append(frame)

        for col in range(6):
            frame_rect = (col * 32, 0, 32, 34)
            frame = blesk_blue_img.subsurface(frame_rect)
            frame = pygame.transform.scale(frame, (self.width + 7, self.height + 7))
            frames_blesk.append(frame)

        self.images = frames_blesk

    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update_time > 1000 * 0.05 : #rychlost se dá měnit zde
            self.last_update_time = now
            self.image_index = (self.image_index + 1) % len(self.images)
        
    def update(self):
        self.animate()
        self.draw()

    def change_location(self):
        random_coords(self)

    def draw(self):
        self.collision_rect = pygame.Rect(self.x, self.y, self.width, self.height)
        self.screen.blit(self.images[self.image_index], (self.x, self.y))



class FallingEnemy():
    #typ blesku, který padá zhora dolů
    def __init__(self):
        self.width = 35
        self.height = 35
        self.blesk_img = pygame.image.load("pictures/blesk.png").convert_alpha()
        self.screen = pygame.display.get_surface()
        self.velocity = 3
        self.x = random.randint(0, self.screen.get_width() - self.width)
        self.y = -100 # tohle číslo je zde z důvodu, aby se blesk neobjevil příliš rychle
        self.collision_rect = pygame.Rect(self.x, self.y, self.width, self.height)

    def update(self):
        self.y += self.velocity
        if self.y >= self.screen.get_height():
            self.change_location()
        self.draw()

    def change_location(self):
        self.x = random.randint(0, self.screen.get_width() - self.width)
        self.y = -100 # tohle číslo je zde znovu z důvodu, aby se blesk neobjevil příliš rychle po zmizení předchozího

    def draw(self):
        self.collision_rect = pygame.Rect(self.x, self.y, self.width, self.height)
        self.screen.blit(self.blesk_img, (self.x, self.y))
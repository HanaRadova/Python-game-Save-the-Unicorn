import pygame
import random

from utils.boundaries import boundaries
from utils.random_coords import random_coords

class Item1:
    def __init__(self):
        self.width = 100
        self.height = 160
        self.screen = pygame.display.get_surface()
        random_coords(self)
        self.collision_rect = pygame.Rect(self.x, self.y, self.width, self.height)
        self.image1 = pygame.image.load(r"pictures\1kredit.png")
        self.image2 = pygame.image.load(r"pictures\2kredity.png")
        self.image3 = pygame.image.load(r"pictures\3kredity.png")
        self.variants = [{"credit":1,  "img": self.image1}, {"credit":2,  "img": self.image2}, {"credit":3,  "img": self.image3}]
        self.variant = self.variants[0]

    def update(self):
        boundaries(self)
        self.draw()

    def draw(self):
        image = pygame.transform.scale(self.variant.get("img"), (self.width, self.height))
        self.screen.blit(image, (self.x, self.y))
        self.collision_rect = pygame.Rect(self.x, self.y, self.width, self.height)

    def move(self):
        random_coords(self)
        self.variant = random.choice(self.variants)


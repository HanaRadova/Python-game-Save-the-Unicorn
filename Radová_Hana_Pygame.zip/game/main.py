import pygame
import sys

from characters.unicorn import Unicorn #hlavní hrdina, jednorožec
from characters.item import Item1 #balónky s kredity
from characters.enemy import FallingEnemy, FloatingEnemy #nepřátelé, blesky
from engine.backround import Background #pozadí, které se pohybuje a slouží pro hlavní hru
from engine.collision_engine import CollisionEngine #řeší srážky
from engine.game_state import GameState #fáze hry
from engine.game_state_enum import GameStatesEnum #zaštiťuje další semestr, menu, konec hry, neuspěšný konec a samotnou hru
from engine.main_menu import Menu #řeší stisnutí kláves spojené s vykreslením pozadí (příběhová linka)

class Main():
    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        # nahrání zvuků při dosažení určitých milníků
        self.victory_sound = pygame.mixer.Sound(r"music\cheer.mp3")
        self.next_sem_sound = pygame.mixer.Sound(r"music\celebration.mp3")
        self.fail_sound = pygame.mixer.Sound(r"music\fail.mp3")

        pygame.display.set_caption("Zachraňte Jednorožce!")
        self.screen_width = 1200
        self.screen_height = 600
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        self.clock = pygame.time.Clock()

        self.setup_game()
        self.game_run()

    def setup_game(self):
        self.unicorn_player = Unicorn(self.screen_width // 2, self.screen_height // 3, 50, 73, 5)
        self.credit = Item1()
        self.enemies = []
        self.enemy1 = FloatingEnemy()
        self.fall_enemy = FallingEnemy()
        self.background = Background()
        self.enemies.append(self.enemy1)
        self.enemies.append(self.fall_enemy)
        self.game_state_instance = GameState()
        self.collision_engine = CollisionEngine(self.credit, self.unicorn_player, self.enemies, self.game_state_instance)
        self.menu = Menu()

    def game_run(self):
        running = True

        while running:
            #následující kód řeší možnost zavření okna a restartu
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYUP and event.key == pygame.K_ESCAPE:
                    running = False
                self.menu.check_space_event(event)
                if GameState().current_state == GameStatesEnum.TryAgain:
                    if event.type == pygame.KEYUP and event.key == pygame.K_r:
                        GameState().init()
                        self.setup_game()

            self.screen.fill((0, 0, 0))
            
            if self.game_state_instance.current_state == GameStatesEnum.Menu:
                self.menu.draw()
                pygame.display.flip()
                self.clock.tick(40)
                continue
            
            if self.game_state_instance.current_state == GameStatesEnum.NextSemester:
                pygame.mixer.music.pause()
                self.next_sem_sound.play()
                self.menu.draw_semester()
                pygame.display.flip()
                self.clock.tick(40)
                continue

            if self.game_state_instance.current_state == GameStatesEnum.TheEnd:
                pygame.mixer.music.pause()
                self.victory_sound.play()
                self.menu.draw_the_end()
                pygame.display.flip()
                self.clock.tick(40)
                continue

            if self.game_state_instance.current_state == GameStatesEnum.TryAgain:
                pygame.mixer.music.pause()
                self.fail_sound.play()
                self.menu.draw_try_again()
                pygame.display.flip()
                self.clock.tick(40)
                continue

            # actual game_loop:
            pygame.mixer.music.unpause()
            self.background.update()
            self.unicorn_player.update()
            self.credit.update()

            for enemy in self.enemies:
                enemy.update()

            self.collision_engine.check_collisions()
            self.game_state_instance.update()
            pygame.display.flip()
            self.clock.tick(40)

        pygame.quit()
        sys.exit()

Main()
import pygame
#tato třída řeší pozadí v hlavním hracím režimu
class Background:
    def __init__(self):
        self.screen = pygame.display.get_surface()
        self.images = []
        self.image_index = 0
        self.frame_counter = 0
        self.last_update_time = 0
        self.images = [pygame.transform.scale(pygame.image.load(r"pictures\backround\obrazek ({}).jpg".format(i)), (self.screen.get_width(), self.screen.get_height())) for i in range(1, 21)]
        #pomocí dosazení čísel v rozmezí 1 až 21 vytváří pohyblivé pozadí
        pygame.mixer.music.load("music/background.mp3")
        pygame.mixer.music.play(-1)#nekonečná smyčka znělky
        
    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update_time > 1000 * 0.09 :#změna rychlosti je možná zde
            self.last_update_time = now
            self.image_index = (self.image_index + 1) % len(self.images)

    def update(self):
        self.animate()
        self.draw()

    def draw(self):
        self.screen.blit(self.images[self.image_index], (0, 0))

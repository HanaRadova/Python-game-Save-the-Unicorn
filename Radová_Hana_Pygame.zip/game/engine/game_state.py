import pygame
import math

from engine.game_state_enum import GameStatesEnum

class GameState:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(GameState, cls).__new__(cls)
            cls.screen = pygame.display.get_surface()
            cls.init(cls)
        return cls._instance

    def init(self):
        self.credits = 0 
        self.current_state = GameStatesEnum.Menu
        self.semester = 1
        self.show_next_semester = False
        self.credits_required = 35 #tady můžete změnit počet kreditů
        self.max_semester = 6 #a zde počet semestrů

    def add_credit(self, value = 1):
        self.credits += value #zde se přičte jeden kredit

    def update(self):
        
        newSemester = math.floor(self.credits / self.credits_required) + 1
        if (newSemester == self.max_semester + 1):
            self.current_state = GameStatesEnum.TheEnd 
            #zde je logika pro stanovení úspěšně ukončené hry

        if (newSemester > self.semester):
            self.semester = newSemester
            self.current_state = GameStatesEnum.NextSemester
            #zde je logika pro stanovení úspěšně ukončeného semestru
        
        self.draw()

    def draw(self):
        font = pygame.font.Font(None, 36)
        text = font.render(f"{self.semester} SEMESTR", True, (255, 191, 191))
        self.screen.blit(text, (10, 10))

        text2 = font.render("KREDITY: " + str(self.credits), True, (255, 191, 191))
        self.screen.blit(text2, (10, 50))

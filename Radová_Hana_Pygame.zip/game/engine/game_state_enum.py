from enum import Enum

class GameStatesEnum(Enum):
    NextSemester = "NexSemester"
    Menu = "Menu"
    TheEnd = "TheEnd"
    TryAgain = "TryAgain"
    GameLoop = "GameLoop"
    
#slouží k lepší orientaci v kódu
#dělí se na fáze hry: další semestr, menu, konec hry, neuspěšný konec a samotnou hru
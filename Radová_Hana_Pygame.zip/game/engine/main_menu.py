import pygame

from engine.game_state import GameState
from engine.game_state_enum import GameStatesEnum

class Menu():
    def __init__(self):
        self.screen = pygame.display.get_surface()
        #ze složky příběhu si vložíme všechna pozadí pro vyvětlení hry i příběhu
        self.images = [pygame.transform.scale(pygame.image.load(r"pictures\backround_story_line\{}.png".format(i)), self.screen.get_size()) for i in range(1, 7)]
        self.current_image = 0
        self.next_semester_img = pygame.transform.scale(pygame.image.load(r"pictures\backround_story_line\next_semester.png"),self.screen.get_size())
        self.the_end_img = pygame.transform.scale(pygame.image.load(r"pictures\backround_story_line\the_end.png"),self.screen.get_size())
        self.try_again_img = pygame.transform.scale(pygame.image.load(r"pictures\backround_story_line\error.png"),self.screen.get_size())

    def check_space_event(self, event):
        if event.type == pygame.KEYUP and event.key == pygame.K_SPACE:
            if GameState().current_state == GameStatesEnum.Menu: 
                self.current_image += 1
                if (self.current_image == (len(self.images))): #pokud již nemáme další obrázky v menu
                    GameState().current_state = GameStatesEnum.GameLoop #přejdeme do fáze hry

            elif GameState().current_state == GameStatesEnum.NextSemester:
                GameState().current_state = GameStatesEnum.GameLoop
    
    #vykreslení různých milníků a nebo konců
    def draw_semester(self):
        self.screen.blit(self.next_semester_img, (0, 0))

    def draw_the_end(self):
        self.screen.blit(self.the_end_img, (0, 0))

    def draw_try_again(self):
        self.screen.blit(self.try_again_img, (0, 0))

    def draw(self):
        self.screen.blit(self.images[self.current_image], (0, 0))
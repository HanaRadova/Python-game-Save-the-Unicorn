from engine.game_state import GameState
from characters.item import Item1
from characters.unicorn import Unicorn
from engine.game_state_enum import GameStatesEnum


class CollisionEngine:
    def __init__(self, item: Item1, unicorn: Unicorn, enemies, game_state: GameState):
        self.game_state = game_state
        self.item = item
        self.unicorn = unicorn
        self.enemies = enemies

    def check_collisions(self):
        if self.unicorn.collision_rect.colliderect(self.item.collision_rect):
            self.game_state.add_credit(self.item.variant.get("credit"))
            self.item.move()
            #pokud se dva obdelníky dotknou(které nejsou vykreslené na obrazovce, ale jsou využité právě k rozenání dotyku s jinými)
            #a tyto obkelníky jsou z tříd Unicorn a Item, tak se přičtou kredity

        for enemy in self.enemies:
            if self.unicorn.collision_rect.colliderect(enemy.collision_rect):
                self.unicorn.hp -= 1 #při srážce s obdelníkem jednoho z blesků (enemy) se jednorožci odečte život
                enemy.change_location()
                
                if (self.unicorn.hp == 0): #až nemá žádný
                    GameState().current_state = GameStatesEnum.TryAgain
                    #zobrazí se pozadí neúspěšného dokončení


